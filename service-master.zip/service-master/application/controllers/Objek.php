<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Objek extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Objek";
        $data['objek'] = $this->admin->getObjek();
        $this->template->load('templates/dashboard', 'objek/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('kode_objek', 'Kode Objek', 'required|trim');
        $this->form_validation->set_rules('nama_objek', 'Nama Objek', 'required|trim');
        $this->form_validation->set_rules('spek_objek', 'Spesifikasi Objek', 'required|trim');
        $this->form_validation->set_rules('detail_objek', 'Detail Objek', 'required|trim');
        $this->form_validation->set_rules('harga_objek', 'Harga Objek', 'required|trim');
        $this->form_validation->set_rules('tahun_objek', 'Tahun Objek', 'required|trim');
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Objek";
            $this->template->load('templates/dashboard', 'objek/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $save = $this->admin->insert('objek', $input);
            if ($save) {
                set_pesan('data berhasil disimpan.');
                redirect('objek');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('objek/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Objek";
            $data['objek'] = $this->admin->get('objek', ['id_objek' => $id]);
            $this->template->load('templates/dashboard', 'objek/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('objek', 'id_objek', $id, $input);

            if ($update) {
                set_pesan('data berhasil diedit.');
                redirect('objek');
            } else {
                set_pesan('data gagal diedit.');
                redirect('objek/add');
            }
        }
    } 

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('objek', 'id_objek', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('objek');
    }
}
