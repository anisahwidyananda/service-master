<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Snk extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "S&K";
        $data['snk'] = $this->admin->getsnk();
        $this->template->load('templates/dashboard', 'snk/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('nama_snk', 'Nama Snk', 'required|trim');
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "S&K";
            $this->template->load('templates/dashboard', 'snk/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $save = $this->admin->insert('snk', $input);
            if ($save) {
                set_pesan('data berhasil disimpan.');
                redirect('snk');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('snk/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "S&K";
            $data['snk'] = $this->admin->get('snk', ['id_snk' => $id]);
            $this->template->load('templates/dashboard', 'snk/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('snk', 'id_snk', $id, $input);

            if ($update) {
                set_pesan('data berhasil diedit.');
                redirect('snk');
            } else {
                set_pesan('data gagal diedit.');
                redirect('snk/add');
            }
        }
    } 

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('snk', 'id_snk', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('snk');
    }
}
