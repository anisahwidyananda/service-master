<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tipeobjek extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Tipe Objek";
        $data['tipeobjek'] = $this->admin->getTipeobjek();
        $this->template->load('templates/dashboard', 'tipe_objek/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('nama_tipeobjek', 'Nama Objek', 'required|trim');
        $this->form_validation->set_rules('kode_tipeobjek', 'Kode Objek', 'required|trim');
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Tipe Objek";
            $this->template->load('templates/dashboard', 'tipe_objek/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $save = $this->admin->insert('tipe_objek', $input);
            if ($save) {
                set_pesan('data berhasil disimpan.');
                redirect('tipeobjek');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('tipeobjek/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Tipe objek";
            $data['tipeobjek'] = $this->admin->get('tipe_objek', ['id_tipeobjek' => $id]);
            $this->template->load('templates/dashboard', 'tipe_objek/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('tipe_objek', 'id_tipeobjek', $id, $input);

            if ($update) {
                set_pesan('data berhasil diedit.');
                redirect('tipeobjek');
            } else {
                set_pesan('data gagal diedit.');
                redirect('tipeobjek/add');
            }
        }
    } 

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('tipe_objek', 'id_tipeobjek', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('tipeobjek');
    }
}
