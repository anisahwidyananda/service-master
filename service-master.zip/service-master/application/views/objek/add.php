<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Form Objek
                        </h4>
                    </div>
                    <div class="col-auto">
                        <a href="<?= base_url('objek') ?>" class="btn btn-sm btn-secondary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-left"></i>
                            </span>
                            <span class="text">
                                Back
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= $this->session->flashdata('pesan'); ?>
                <?= form_open(''); ?>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="kode_objek">Kode Objek</label>
                    <div class="col-md-4">
                        <input value="" type="text" class="form-control" name="kode_objek">
                        <?= form_error('kode_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="nama_objek">Nama Objek</label>
                    <div class="col-md-4">
                        <input value="" type="text" class="form-control" name="nama_objek">
                        <?= form_error('nama_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="nama_objek">Spesifikasi Objek</label>
                    <div class="col-md-4">
                        <input value="" type="text" class="form-control" name="spek_objek">
                        <?= form_error('spek_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="nama_objek">Detail Objek</label>
                    <div class="col-md-4">
                        <input value="" type="text" class="form-control" name="detail_objek">
                        <?= form_error('detail_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="nama_objek">Harga Objek</label>
                    <div class="col-md-4">
                        <input value="" type="number" class="form-control" name="harga_objek">
                        <?= form_error('harga_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="tahun_objek">Tahun Objek</label>
                    <div class="col-md-4">
                        <input value="" type="number" class="form-control" name="tahun_objek">
                        <?= form_error('tahun_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col offset-md-4">
                        <button type="submit" class="btn btn-tertier">Save</button>
                        <button type="reset" class="btn btn-secondary">Reset</button>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>