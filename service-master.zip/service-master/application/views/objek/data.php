<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-botom-primary">
    <div class="card-header bg-white py-3">
        <div class="row">
            <div class="col">
                <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                    Data Objek
                </h4>
            </div>
            <div class="col-auo">
                <a href="<?= base_url('objek/add') ?>" class="btn btn-sm btn-primary btn-icon-split">
                    <span class="icon">
                        <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">
                        Input Objek
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped w-100 nowrap" id="dataTable">
            <thead>
                <tr>
                    <th>No. </th>
                    <th>Kode Objek</th>
                    <th>Nama Objek</th>
                    <th>Spesifikasi Objek</th>
                    <th>Detail Objek</th>
                    <th>Harga Objek</th>
                    <th>Tahun Objek</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($objek) :
                    foreach ($objek as $key => $o) :
                        ?>
                        <tr>
                            <td><?= $key+1; ?></td>
                            <td><?= $o['kode_objek']; ?></td>
                            <td><?= $o['nama_objek']; ?></td>
                            <td><?= $o['spek_objek']; ?></td>
                            <td><?= $o['detail_objek']; ?></td>
                            <td><?= $o['harga_objek']; ?></td>
                            <td><?= $o['tahun_objek']; ?></td>
                            <td>
                                <a href="<?= base_url('objek/edit/') . $o['id_objek'] ?>" class="btn btn-warning btn-circle btn-sm"><i class="fa fa-edit"></i></a>
                                <a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('objek/delete/') . $o['id_objek'] ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="8" class="text-center">
                            Data Kosong
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>