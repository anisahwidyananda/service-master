<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Form Edit Objek
                        </h4>
                    </div>
                    <div class="col-auto">
                        <a href="<?= base_url('objek') ?>" class="btn btn-sm btn-secondary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-left"></i>
                            </span>
                            <span class="text">
                                Kembali
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= $this->session->flashdata('pesan'); ?>
                <?= form_open('', [], ['id_objek' => $objek['id_objek']]); ?>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="kode_objek">Kode Objek</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('kode_objek', $objek['kode_objek']); ?>" name="kode_objek" id="kode_objek" type="text" class="form-control" placeholder="Kode Objek...">
                        <?= form_error('kode_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="nama_objek">Nama Objek</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('nama_objek', $objek['nama_objek']); ?>" name="nama_objek" id="nama_objek" type="text" class="form-control" placeholder="Nama Objek...">
                        <?= form_error('nama_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="spek_objek">Spesifikasi Objek</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('spek_objek', $objek['spek_objek']); ?>" name="spek_objek" id="spek_objek" type="text" class="form-control" placeholder="Spesifikasi Objek...">
                        <?= form_error('spek_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="detail_objek">Detail Objek</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('detail_objek', $objek['detail_objek']); ?>" name="detail_objek" id="detail_objek" type="text" class="form-control" placeholder="Detail Objek...">
                        <?= form_error('detail_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="harga_objek">Harga objek</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('harga_objek', $objek['harga_objek']); ?>" name="harga_objek" id="harga_objek" type="number" class="form-control" placeholder="Harga Objek...">
                        <?= form_error('harga_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="tahun_objek">Tahun objek</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('tahun_objek', $objek['tahun_objek']); ?>" name="tahun_objek" id="tahun_objek" type="number" class="form-control" placeholder="Tahun Objek...">
                        <?= form_error('tahun_objek', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-md-9 offset-md-3">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>