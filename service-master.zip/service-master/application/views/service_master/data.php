<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
    <div class="card-header bg-white py-3">
        <div class="row">
            <div class="col">
                <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                    Riwayat Data Service Master
                </h4>
            </div>
            <div class="col-auto">
                <a href="<?= base_url('servicemaster/add') ?>" class="btn btn-sm btn-primary btn-icon-split">
                    <span class="icon">
                        <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">
                        Input Data
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped w-100 nowrap" id="dataTable">
            <thead>
                <tr>
                    <th>No. </th>
                    <th>Periode</th>
                    <th>SP (Existing)</th>
                    <th>Add</th>
                    <th>SP (SAP)</th>
                    <th>User</th>
                    <th>Objective</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Header</th>
                    <th>Count 1</th>
                    <th>Service No.</th>
                    <th>Service</th>
                    <th>Count 2</th>
                    <th>Description</th>
                    <th>Qty</th>
                    <th>Unit</th>
                    <th>Price</th>
                    <th>Contract Type</th>
                    <th>Partner</th>
                    <th>Note</th>
                    <th>Hapus</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($servicemaster) :
                    foreach ($servicemaster as $sm) :
                        ?>
                        <tr>
                            <td><?= $sm['no']; ?></td>
                            <td><?= $sm['periode']; ?></td>
                            <td><?= $sm['sp_existing']; ?></td>
                            <td><?= $sm['add_']; ?></td>
                            <td><?= $sm['sp_sap']; ?></td>
                            <td><?= $sm['user']; ?></td>
                            <td><?= $sm['objective']; ?></td>
                            <td><?= $sm['from_']; ?></td>
                            <td><?= $sm['to_']; ?></td>
                            <td><?= $sm['header']; ?></td>
                            <td><?= $sm['count1']; ?></td>
                            <td><?= $sm['service_no']; ?></td>
                            <td><?= $sm['service']; ?></td>
                            <td><?= $sm['count2']; ?></td>
                            <td><?= $sm['description']; ?></td>
                            <td><?= $sm['qty']; ?></td>
                            <td><?= $sm['unit']; ?></td>
                            <td><?= $sm['price']; ?></td>
                            <td><?= $sm['contrac_type']; ?></td>
                            <td><?= $sm['partner']; ?></td>
                            <td><?= $sm['note']; ?></td>
                            <td>
                                <a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('servicemaster/delete/') . $sm['no'] ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="22" class="text-center">
                            Data Kosong
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>