<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
    <div class="card-header bg-white py-3">
        <div class="row">
            <div class="col">
                <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                    Data Tipe Objek
                </h4>
            </div>
            <div class="col-auto">
                <a href="<?= base_url('tipeobjek/add') ?>" class="btn btn-sm btn-primary btn-icon-split">
                    <span class="icon">
                        <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">
                        Input Tipe Objek
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped w-100 dt-responsive nowrap" id="dataTable">
            <thead>
                <tr>
                    <th>No. </th>
                    <th>Kode Tipe Objek</th>
                    <th>Nama Tipe Objek</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($tipeobjek) :
                    foreach ($tipeobjek as $key => $to) :
                        ?>
                        <tr>
                            <td><?= $key+1; ?></td>
                            <td><?= $to['kode_tipeobjek']; ?></td>
                            <td><?= $to['nama_tipeobjek']; ?></td>
                            <td>
                                <a href="<?= base_url('tipeobjek/edit/') . $to['id_tipeobjek'] ?>" class="btn btn-warning btn-circle btn-sm"><i class="fa fa-edit"></i></a>
                                <a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('tipeobjek/delete/') . $to['id_tipeobjek'] ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="8" class="text-center">
                            Data Kosong
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>