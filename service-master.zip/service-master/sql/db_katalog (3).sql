-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Sep 2020 pada 07.19
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_katalog`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `objek`
--

CREATE TABLE `objek` (
  `id_objek` int(11) NOT NULL,
  `id_tipeobjek` int(11) NOT NULL,
  `kode_objek` varchar(45) DEFAULT NULL,
  `nama_objek` varchar(125) DEFAULT NULL,
  `spek_objek` varchar(45) DEFAULT NULL,
  `detail_objek` varchar(125) DEFAULT NULL,
  `harga_objek` int(11) DEFAULT NULL,
  `tahun_objek` year(4) DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT current_timestamp(),
  `update_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `objek`
--

INSERT INTO `objek` (`id_objek`, `id_tipeobjek`, `kode_objek`, `nama_objek`, `spek_objek`, `detail_objek`, `harga_objek`, `tahun_objek`, `create_at`, `update_at`) VALUES
(1, 0, '2357', 'Panther', 'Terios', 'Isuzu-Panther-LV-MT-2011', 6250000, 2011, '2020-09-13 08:48:22', '2020-09-13 08:48:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `partner`
--

CREATE TABLE `partner` (
  `id_partner` int(11) NOT NULL,
  `nama_partner` varchar(125) DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT current_timestamp(),
  `update_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `partner`
--

INSERT INTO `partner` (`id_partner`, `nama_partner`, `create_at`, `update_at`) VALUES
(1, 'YAYASAN PETROKIMIA GRESIK', '2020-09-13 12:27:26', '2020-09-13 12:27:26');

-- --------------------------------------------------------

--
-- Struktur dari tabel `service_master`
--

CREATE TABLE `service_master` (
  `id_servicemaster` int(11) NOT NULL,
  `id_objek` int(11) NOT NULL,
  `id_snk` int(11) NOT NULL,
  `id_partner` int(11) NOT NULL,
  `periode` year(4) DEFAULT NULL,
  `sp_existing` varchar(45) DEFAULT NULL,
  `add` varchar(45) DEFAULT NULL,
  `sp_sap` varchar(45) DEFAULT NULL,
  `user` varchar(45) DEFAULT NULL,
  `from` date DEFAULT NULL,
  `to` date DEFAULT NULL,
  `header` varchar(45) DEFAULT NULL,
  `count1` varchar(45) DEFAULT NULL,
  `service_no` varchar(45) DEFAULT NULL,
  `service` varchar(45) DEFAULT NULL,
  `count2` varchar(45) DEFAULT NULL,
  `description` varchar(125) DEFAULT NULL,
  `qty` varchar(45) DEFAULT NULL,
  `unit` varchar(45) DEFAULT NULL,
  `price` varchar(45) DEFAULT NULL,
  `contrac_type` varchar(45) DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT current_timestamp(),
  `update_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `snk`
--

CREATE TABLE `snk` (
  `id_snk` int(11) NOT NULL,
  `nama_snk` varchar(45) DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT current_timestamp(),
  `update_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `snk`
--

INSERT INTO `snk` (`id_snk`, `nama_snk`, `create_at`, `update_at`) VALUES
(1, 'InJava', '2020-09-13 12:45:19', '2020-09-13 12:45:19'),
(2, 'OuJava', '2020-09-13 12:45:35', '2020-09-13 12:45:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tipe_jasa`
--

CREATE TABLE `tipe_jasa` (
  `id_tipejasa` int(11) NOT NULL,
  `nama_jasa` varchar(125) DEFAULT NULL,
  `kode_jasa` varchar(45) DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT current_timestamp(),
  `update_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tipe_jasa`
--

INSERT INTO `tipe_jasa` (`id_tipejasa`, `nama_jasa`, `kode_jasa`, `create_at`, `update_at`) VALUES
(1, 'Sewa Menyewa', 'RENT', '2020-09-12 05:34:09', '2020-09-12 11:52:32'),
(2, 'Pengecatan Piping & Peralatan Pabrik', 'PAINT', '2020-09-12 12:38:31', '2020-09-12 13:01:04');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tipe_objek`
--

CREATE TABLE `tipe_objek` (
  `id_tipeobjek` int(11) NOT NULL,
  `id_tipejasa` int(11) NOT NULL,
  `kode_tipeobjek` varchar(125) DEFAULT NULL,
  `nama_tipeobjek` varchar(125) DEFAULT NULL,
  `create_at` timestamp NULL DEFAULT current_timestamp(),
  `update_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `tipe_objek`
--

INSERT INTO `tipe_objek` (`id_tipeobjek`, `id_tipejasa`, `kode_tipeobjek`, `nama_tipeobjek`, `create_at`, `update_at`) VALUES
(1, 1, 'STATION', 'Kendaraan Bermotor', '2020-09-12 15:24:16', '2020-09-12 15:53:06'),
(2, 0, 'EXCAVATOR', 'Excavator', '2020-09-12 15:28:20', '2020-09-12 16:13:43');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `role` enum('gudang','admin') NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` int(11) NOT NULL,
  `foto` text NOT NULL,
  `is_active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama`, `username`, `email`, `no_telp`, `role`, `password`, `created_at`, `foto`, `is_active`) VALUES
(1, 'Adminisitrator', 'admin', 'admin@admin.com', '025123456789', 'admin', '$2y$10$qJzoztcJWLao7/cxruqG8.cmWzQlBjY5RfG3ic1c0KB6ex..tsGyu', 1568689561, 'd5f22535b639d55be7d099a7315e1f7f.png', 1),
(17, 'gudang', 'gudang1', 'gudang1@gmail.com', '0877373727', 'gudang', '$2y$10$As3BI1.5UVaA0YV25fMVIO3Fak89d1C9cvFEKTXckwk3A/CkfSxkO', 1591191456, 'user.png', 1),
(18, 'anisah', 'anisah', 'anisahwidya99@gmail.com', '0895639463384', 'admin', '$2y$10$SGPL84nS2IMAw8.KBJ/h7eIpMxmZY4H3NcvBtq9gKQjbceNuKcglG', 1598083892, 'user.png', 1),
(19, 'gudang2', 'gudang2', 'gudang2@gmail.com', '0895639463384', 'gudang', '$2y$10$t4nzMZiAWeUPDk7u4fBWzO2sNKBTHhXIfNO4gzNwXGhQH5aI15PHi', 1598527423, 'user.png', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `objek`
--
ALTER TABLE `objek`
  ADD PRIMARY KEY (`id_objek`);

--
-- Indeks untuk tabel `partner`
--
ALTER TABLE `partner`
  ADD PRIMARY KEY (`id_partner`);

--
-- Indeks untuk tabel `service_master`
--
ALTER TABLE `service_master`
  ADD PRIMARY KEY (`id_servicemaster`);

--
-- Indeks untuk tabel `snk`
--
ALTER TABLE `snk`
  ADD PRIMARY KEY (`id_snk`);

--
-- Indeks untuk tabel `tipe_jasa`
--
ALTER TABLE `tipe_jasa`
  ADD PRIMARY KEY (`id_tipejasa`);

--
-- Indeks untuk tabel `tipe_objek`
--
ALTER TABLE `tipe_objek`
  ADD PRIMARY KEY (`id_tipeobjek`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`) USING BTREE,
  ADD UNIQUE KEY `username` (`username`) USING BTREE;

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `objek`
--
ALTER TABLE `objek`
  MODIFY `id_objek` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `partner`
--
ALTER TABLE `partner`
  MODIFY `id_partner` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `service_master`
--
ALTER TABLE `service_master`
  MODIFY `id_servicemaster` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `snk`
--
ALTER TABLE `snk`
  MODIFY `id_snk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tipe_jasa`
--
ALTER TABLE `tipe_jasa`
  MODIFY `id_tipejasa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tipe_objek`
--
ALTER TABLE `tipe_objek`
  MODIFY `id_tipeobjek` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
