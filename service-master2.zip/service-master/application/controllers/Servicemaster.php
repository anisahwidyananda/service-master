<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Servicemaster extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Service Master";
        $data['servicemaster'] = $this->admin->getServiceMaster();
        $this->template->load('templates/dashboard', 'service_master/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('periode', 'Periode', 'required|trim');
        $this->form_validation->set_rules('sp_existing', 'SP (Existing)', 'required|trim');
        $this->form_validation->set_rules('add', 'Addendum', 'required|trim');
        $this->form_validation->set_rules('sp_sap', 'No. Agreement', 'required|trim');
        $this->form_validation->set_rules('user', 'User', 'required|trim');
        $this->form_validation->set_rules('objective', 'Objective', 'required|trim');
        $this->form_validation->set_rules('from', 'From', 'required|trim');
        $this->form_validation->set_rules('to', 'To', 'required|trim');
        $this->form_validation->set_rules('header', 'Header', 'required|trim');
        $this->form_validation->set_rules('service_no', 'Service No.', 'required|trim');
        $this->form_validation->set_rules('service', 'Service', 'required|trim');
        $this->form_validation->set_rules('description', 'Description', 'required|trim');
        $this->form_validation->set_rules('qty', 'Qty', 'required|trim');
        $this->form_validation->set_rules('unit', 'Unit', 'required|trim');
        $this->form_validation->set_rules('price', 'Price', 'required|trim');
        $this->form_validation->set_rules('contrac_type', 'Contrac Type', 'required|trim');
        $this->form_validation->set_rules('partner', 'Partner', 'required|trim');
        $this->form_validation->set_rules('note', 'Note', 'required|trim');
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Service Master";
            $data['servicemaster'] = $this->admin->get('service_master');
           
            $this->template->load('templates/dashboard', 'service_master/add', $data);
        } 
        else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('service_master', $input);

            if ($insert) {
                set_pesan('data berhasil disimpan.');
                redirect('servicemaster');
            } else {
                set_pesan('Opps ada kesalahan!');
                redirect('servicemaster/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Service Master";
            $data['servicemaster'] = $this->admin->get('service_master', ['id_servicemaster' => $id]);
            $this->template->load('templates/dashboard', 'service_master/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('service_master', 'id_servicemaster', $id, $input);

            if ($update) {
                set_pesan('data berhasil diedit.');
                redirect('servicemaster');
            } else {
                set_pesan('data gagal diedit.');
                redirect('servicemaster/add');
            }
        }
    } 

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('service_master', 'id_servicemaster', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('servicemaster');
    }
}
