<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    public function get($table, $data = null, $where = null)
    {
        if ($data != null) {
            return $this->db->get_where($table, $data)->row_array();
        } else {
            return $this->db->get_where($table, $where)->result_array();
        }
    }

    public function update($table, $pk, $id, $data)
    {
        $this->db->where($pk, $id);
        return $this->db->update($table, $data);
    }

    public function insert($table, $data, $batch = false)
    {
        return $batch ? $this->db->insert_batch($table, $data) : $this->db->insert($table, $data);
    }

    public function delete($table, $pk, $id)
    {
        return $this->db->delete($table, [$pk => $id]);
    }

    public function getUsers($id)
    {
        /**
         * ID disini adalah untuk data yang tidak ingin ditampilkan. 
         * Maksud saya disini adalah 
         * tidak ingin menampilkan data user yang digunakan, 
         * pada managemen data user
         */
        $this->db->where('id_user !=', $id);
        return $this->db->get('user')->result_array();
    }

    public function getServiceMaster($limit = null, $no = null, $range = null)
    {
        $this->db->select('*');
        return $this->db->get('service_master sm')->result_array();
    }

    public function getKategori($limit = null, $no = null, $range = null)
    {
        $this->db->select('*');
        return $this->db->get('kategori_service ks')->result_array();
    }

    /*public function getObjek($limit = null, $id = null, $range = null)
    {
        $this->db->select('*');
        //$this->db->from('objek');
        //$this->db->join('tipe_objek', 'tipe_objek.id_tipeobjek = objek.id_tipeobjek');

        return $this->db->get('objek o')->result_array();
    }

    public function getTipeJasa($limit = null, $id = null, $range = null)
    {
        $this->db->select('*');
        return $this->db->get('tipe_jasa tj')->result_array();
    }

    public function getTipeObjek($limit = null, $id = null, $range = null)
    {
        $this->db->select('*');
        $this->db->from('tipe_objek');
        $this->db->join('tipe_jasa', 'tipe_jasa.id_tipejasa = tipe_objek.id_tipejasa');

        return $this->db->get('tipe_objek to')->result_array();
    }

    public function getPartner($limit = null, $id = null, $range = null)
    {
        $this->db->select('*');
        return $this->db->get('partner p')->result_array();
    }

    public function getSnk($limit = null, $id = null, $range = null)
    {
        $this->db->select('*');
        return $this->db->get('snk s')->result_array();
    } */

    public function laporan($table, $mulai, $akhir)
    {
        //$tgl = $table == 'barang_masuk' ? 'tanggal_masuk' : 'tanggal_keluar';
        $this->db->where($tgl . ' >=', $mulai);
        $this->db->where($tgl . ' <=', $akhir);
        return $this->db->get($table)->result_array();
    }
}
