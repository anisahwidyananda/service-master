<?= $this->session->flashdata('pesan'); ?>
<div class="card shadow-sm border-bottom-primary">
    <div class="card-header bg-white py-3">
        <div class="row">
            <div class="col">
                <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                    Data Kategori Service
                </h4>
            </div>
            <div class="col-auto">
                <a href="<?= base_url('kategori/add') ?>" class="btn btn-sm btn-primary btn-icon-split">
                    <span class="icon">
                        <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">
                        Tambah Kategori
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped w-100 nowrap" id="dataTable">
            <thead>
                <tr>
                    <th>No. </th>
                    <th>Service No.</th>
                    <th>Tipe Jasa</th>
                    <th>Detail Objek</th>
                    <th>S&K</th>
                    <th>Service</th>
                    <th>Hapus</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($kategori) :
                    foreach ($kategori as $key => $ks) :
                        ?>
                        <tr>
                            <td><?= $key+1; ?></td>
                            <td><?= $ks['service_no']; ?></td>
                            <td><?= $ks['tipe_jasa']; ?></td>
                            <td><?= $ks['detail_objek']; ?></td>
                            <td><?= $ks['snk']; ?></td>
                            <td><?= $ks['service']; ?></td>
                            <td>
                                <a href="<?= base_url('kategori/edit/') . $ks['id_kategoriservice'] ?>" class="btn btn-warning btn-circle btn-sm"><i class="fa fa-edit"></i></a>
                                <a onclick="return confirm('Yakin ingin hapus?')" href="<?= base_url('kategori/delete/') . $ks['id_kategoriservice'] ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="8" class="text-center">
                            Data Kosong
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>