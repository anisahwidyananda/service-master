<div class="row justify-content-center">
    <div class="col-md-9">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Form Input Data
                        </h4>
                    </div>
                    <div class="col-auto">
                        <a href="<?= base_url('servicemaster') ?>" class="btn btn-sm btn-secondary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-left"></i>
                            </span>
                            <span class="text">
                                Back
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= $this->session->flashdata('pesan'); ?>
                <?= form_open(); ?>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Periode</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('periode'); ?>" name="periode" id="periode" type="number" class="form-control" placeholder="Periode...">
                        <?= form_error('periode', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">SP Existing</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('sp_existing'); ?>" name="sp_existing" id="sp_existing" type="text" class="form-control" placeholder="SP Existing...">
                        <?= form_error('sp_existing', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Add</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('add'); ?>" name="add" id="add" type="number" class="form-control" placeholder="Addendum...">
                        <?= form_error('add', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">No. Agreement</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('sp_sap'); ?>" name="sp_sap" id="sp_sap" type="text" class="form-control" placeholder="No. Agreement...">
                        <?= form_error('sp_sap', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">User</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('user'); ?>" name="user" id="user" type="text" class="form-control" placeholder="User...">
                        <?= form_error('user', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Objective</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('objective'); ?>" name="objective" id="objective" type="varchar" class="form-control" placeholder="Objective...">
                        <?= form_error('objective', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">From</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('from'); ?>" name="from" id="from" type="date" class="form-control" placeholder="From...">
                        <?= form_error('from', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">To</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('to'); ?>" name="to" id="to" type="date" class="form-control" placeholder="To...">
                        <?= form_error('to', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Header</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('header'); ?>" name="header" id="header" type="text" class="form-control" placeholder="Header...">
                        <?= form_error('header', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Service No.</label>
                    <div class="col-md-9">
                        <div class="input-group">
                            <select name="service_no" id="service_no" class="custom-select">
                                <option value="" selected disabled>Pilih Service No.</option>
                                <?php foreach ($kategori as $ks) : ?>
                                    <option <?= set_select('service_no', $ks['service_no']) ?> value="<?= $ks['service_no'] ?>"><?= $ks['service_no'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="input-group-append">
                                <a class="btn btn-primary" href="<?= base_url('kategori/add'); ?>"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <?= form_error('service_no', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Service</label>
                    <div class="col-md-9">
                        <div class="input-group">
                            <select name="service" id="service" class="custom-select">
                                <option value="" selected disabled>Pilih Service</option>
                                <?php foreach ($kategori as $ks) : ?>
                                    <option <?= set_select('service', $ks['service']) ?> value="<?= $ks['service'] ?>"><?= $ks['service'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="input-group-append">
                                <a class="btn btn-primary" href="<?= base_url('kategori/add'); ?>"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <?= form_error('service', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Description</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('description'); ?>" name="description" id="description" type="text" class="form-control" placeholder="Description...">
                        <?= form_error('description', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Qty</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('qty'); ?>" name="qty" id="qty" type="number" class="form-control" placeholder="Qty...">
                        <?= form_error('qty', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Unit</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('unit'); ?>" name="unit" id="unit" type="text" class="form-control" placeholder="Unit...">
                        <?= form_error('unit', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Price</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('price'); ?>" name="price" id="price" type="number" class="form-control" placeholder="Price...">
                        <?= form_error('price', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Description</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('description'); ?>" name="description" id="description" type="text" class="form-control" placeholder="Description...">
                        <?= form_error('description', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Contrac Type</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('contrac_type'); ?>" name="contrac_type" id="text" type="text" class="form-control" placeholder="Contrac Type...">
                        <?= form_error('contrac_type', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Partner</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('partner'); ?>" name="partner" id="partner" type="text" class="form-control" placeholder="Partner...">
                        <?= form_error('partner', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="service_master">Note</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('note'); ?>" name="note" id="note" type="text" class="form-control" placeholder="Note...">
                        <?= form_error('note', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-md-9 offset-md-3">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <button type="reset" class="btn btn-secondary">Reset</button>
                    </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>