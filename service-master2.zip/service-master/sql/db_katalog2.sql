-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Sep 2020 pada 15.40
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_katalog2`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_service`
--

CREATE TABLE `kategori_service` (
  `id_kategoriservice` int(255) NOT NULL,
  `service_no` char(255) DEFAULT NULL,
  `tipe_jasa` char(255) NOT NULL,
  `detail_objek` varchar(255) NOT NULL,
  `snk` varchar(255) NOT NULL,
  `service` char(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kategori_service`
--

INSERT INTO `kategori_service` (`id_kategoriservice`, `service_no`, `tipe_jasa`, `detail_objek`, `snk`, `service`) VALUES
(1, '11.410000XXXX.001\r\n', 'Rent', 'Isuzu-Panther-LV-MT-2011', 'InJava', 'Rent|Isuzu-Panther-LV-MT-2011|InJava'),
(2, '11.410000XXXX.002\r\n', 'Rent', 'Isuzu-Panther-LV-MT-2011', 'OuJava', 'Rent|Isuzu-Panther-LV-MT-2011|OuJava'),
(3, '11.410000XXXX.003\r\n', 'Rent', 'Daihatsu-Terios-MT-2011', 'InJava', 'Rent|Daihatsu-Terios-MT-2011|InJava'),
(4, '12.410000XXXX.001\r\n', 'Rent', 'Toyota-Innova-2.0-G-MT-2012', 'InJava', 'Rent|Toyota-Innova-2.0-G-MT-2012|InJava\r\n'),
(5, '12.410000XXXX.002\r\n', 'Rent', 'Toyota-Innova-2.0-G-MT-2012', 'InJava', 'Rent|Toyota-Innova-2.0-G-MT-2012|InJava\r\n'),
(6, '12.410000XXXX.003\r\n', 'Rent', 'Toyota-Innova-2.0-G-MT-2012', 'InJava', 'Rent|Toyota-Innova-2.0-G-MT-2012|InJava\r\n'),
(7, '12.410000XXXX.001\r\n', 'Rent', 'Toyota-Alphard-2.4-G-2012', 'InJava', 'Rent|Toyota-Alphard-2.4-G-2012|InJava\r\n'),
(8, '12.410000XXXX.002\r\n', 'Rent', 'Toyota-Alphard-3.5-V-2012', 'InJava', 'Rent|Toyota-Alphard-3.5-V-2012|InJava\r\n'),
(9, '12.410000XXXX.001\r\n', 'Rent', 'Excavator-PC200', 'AllIn', 'Rent|Excavator-PC200|AllIn\r\n'),
(10, '13.410000XXXX.001\r\n', 'Rent', 'Toyota-Innova-2.0-G-MT-2012', 'InJava', 'Rent|Toyota-Innova-2.0-G-MT-2012|InJava\r\n'),
(11, '13.410000XXXX.002\r\n', 'Rent', 'Toyota-Avanza-1.5-G-MT-2012', 'InJava', 'Rent|Toyota-Avanza-1.5-G-MT-2012|InJava\r\n'),
(12, '13.410000XXXX.001\r\n', 'Rent', 'Suzuki-MegaCarry-ExtraW-2013', 'InJava', 'Rent|Suzuki-MegaCarry-ExtraW-2013|InJava\r\n'),
(13, '14.410000XXXX.001\r\n', 'Paint', 'Prim-ChloRub-ChloRub', '0~6m2', 'Paint|Prim-ChloRub-ChloRub|0~6m2\r\n'),
(14, '14.410000XXXX.002\r\n', 'Paint', 'Prim-ChloRub-ChloRub', '7~12m2', 'Paint|Prim-ChloRub-ChloRub|7~12m2\r\n'),
(15, '14.410000XXXX.003\r\n', 'Paint', 'Prim-ChloRub-ChloRub', '12~20m2', 'Paint|Prim-ChloRub-ChloRub|12~20m2\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `service_master`
--

CREATE TABLE `service_master` (
  `id_servicemaster` int(255) NOT NULL,
  `periode` year(4) NOT NULL,
  `sp_existing` varchar(255) NOT NULL,
  `add` int(45) NOT NULL,
  `sp_sap` char(255) NOT NULL,
  `user` varchar(125) NOT NULL,
  `objective` varchar(255) NOT NULL,
  `from` date NOT NULL,
  `to` date NOT NULL,
  `header` varchar(255) NOT NULL,
  `service_no` char(255) NOT NULL,
  `service` char(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `qty` int(125) NOT NULL,
  `unit` varchar(125) NOT NULL,
  `price` varchar(255) NOT NULL,
  `contrac_type` varchar(255) NOT NULL,
  `partner` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `service_master`
--

INSERT INTO `service_master` (`id_servicemaster`, `periode`, `sp_existing`, `add`, `sp_sap`, `user`, `objective`, `from`, `to`, `header`, `service_no`, `service`, `description`, `qty`, `unit`, `price`, `contrac_type`, `partner`, `note`) VALUES
(1, 2011, '2357/TU.04.06/12/SP/2011', 0, '410000XXXX\r\n', 'YANUM', 'Sewa Menyewa Kendaraan Bermotor - Panther - Terios - 2011\r\n', '2012-03-06', '2017-03-05', 'RENT|STATION|PANTHER-TERIOS-2011\r\n', '11.410000XXXX.001\r\n', 'Rent|Isuzu-Panther-LV-MT-2011|InJava', 'Sewa Isuzu Panther wilayah Pulau Jawa\r\n', 1, 'UN', '6250000', ' Unit Price \r\n', 'YAYASAN PETROKIMIA GRESIK\r\n', 'YPG'),
(2, 2011, '2357/TU.04.06/12/SP/2011\r\n', 0, '410000XXXX\r\n', 'YANUM', 'Sewa Menyewa Kendaraan Bermotor - Panther - Terios - 2011\r\n', '2012-03-06', '2017-03-05', 'RENT|STATION|PANTHER-TERIOS-2011\r\n', '11.410000XXXX.002\r\n', 'Rent|Isuzu-Panther-LV-MT-2011|OuJava', 'Sewa Isuzu Panther wilayah luar Pulau Jawa\r\n', 1, 'UN', '6650000', ' Unit Price \r\n', 'YAYASAN PETROKIMIA GRESIK\r\n', 'YPG'),
(3, 2011, '2357/TU.04.06/12/SP/2011\r\n', 0, '410000XXXX\r\n', 'YANUM', 'Sewa Menyewa Kendaraan Bermotor - Panther - Terios - 2011\r\n', '2012-03-06', '2017-03-05', 'RENT|STATION|PANTHER-TERIOS-2011\r\n', '11.410000XXXX.003\r\n', 'Rent|Daihatsu-Terios-MT-2011|InJava', 'Sewa Daihatsu Terios wilayah luar Pulau Jawa\r\n', 1, 'UN', '5850000', ' Unit Price \r\n', 'YAYASAN PETROKIMIA GRESIK\r\n', 'YPG'),
(4, 2012, '0653/TU.04.06/12/SP/2012\r\n', 0, '410000XXXX\r\n', 'YANUM', 'Sewa Menyewa Kendaraan Bermotor - Innova - 2012\r\n', '2012-04-23', '2017-04-22', 'RENT|STATION|INNOVA-2012\r\n', '12.410000XXXX.001\r\n', 'Rent|Toyota-Innova-2.0-G-MT-2012|InJava\r\n', 'Harga sewa kendaraan bermotor\r\n', 1, 'UN', '7000000', ' Unit Price \r\n', 'YAYASAN PETROKIMIA GRESIK\r\n', 'YPG'),
(5, 2012, '0653/TU.04.06/12/SP/2012\r\n', 0, '410000XXXX\r\n', 'YANUM', 'Sewa Menyewa Kendaraan Bermotor - Innova - 2012\r\n', '2012-04-24', '2017-04-23', 'RENT|STATION|INNOVA-2013\r\n', '12.410000XXXX.002\r\n', 'Rent|Toyota-Innova-2.0-G-MT-2012|InJava\r\n', 'Harga sewa kendaraan bermotor bersifat tetap\r\n', 1, 'UN', '7000000', ' Unit Price \r\n', 'YAYASAN PETROKIMIA GRESIK\r\n', 'YPG'),
(6, 2012, '0653/TU.04.06/12/SP/2012\r\n', 0, '410000XXXX\r\n', 'YANUM', 'Sewa Menyewa Kendaraan Bermotor - Innova - 2012\r\n', '2012-04-25', '2017-04-24', 'RENT|STATION|INNOVA-2014\r\n', '12.410000XXXX.003\r\n', 'Rent|Toyota-Innova-2.0-G-MT-2012|InJava\r\n', 'Harga sewa termasuk biaya pemeliharaan, perpanjangan STNK, KIR & Asuransi\r\n', 1, 'UN', '7000000', ' Unit Price \r\n', 'YAYASAN PETROKIMIA GRESIK\r\n', 'YPG'),
(7, 2012, '1258/TU.04.06/12/SP/2012\r\n', 0, '410000XXXX\r\n', 'YANUM', 'Sewa Menyewa Kendaraan Bermotor - Alphard - 2012\r\n', '2012-09-02', '2017-09-01', 'RENT|STATION|ALPHARD-2.4G-3.5V-2012\r\n', '12.410000XXXX.001\r\n', 'Rent|Toyota-Alphard-2.4-G-2012|InJava\r\n', 'Type 2.4 G\r\n', 1, 'UN', '20000000', ' Unit Price \r\n', 'YAYASAN PETROKIMIA GRESIK\r\n', 'YPG'),
(8, 2012, '1258/TU.04.06/12/SP/2012\r\n', 0, '410000XXXX\r\n', 'YANUM', 'Sewa Menyewa Kendaraan Bermotor - Alphard - 2012\r\n', '2012-09-02', '2017-09-01', 'RENT|STATION|ALPHARD-2.4G-3.5V-2012\r\n', '12.410000XXXX.002\r\n', 'Rent|Toyota-Alphard-3.5-V-2012|InJava\r\n', 'Type 3.5 V\r\n', 1, 'UN', '25200000', ' Unit Price \r\n', 'YAYASAN PETROKIMIA GRESIK\r\n', 'YPG'),
(9, 2012, '2279/TU.04.06/09/SP/2012\r\n', 0, '410000XXXX\r\n', 'FABRIKASI', 'Sewa Excavator PC-200 untuk Operasional Pabrik 1/2/3\r\n', '2011-11-01', '2016-10-31', 'RENT|EXCAVATOR|PC200\r\n', '12.410000XXXX.001\r\n', 'Rent|Excavator-PC200|AllIn\r\n', 'Secara borongan\r\n', 1, 'UN', '67000000', ' Unit Price \r\n', 'PETROKOPINDO CIPTA SELARAS, PT\r\n', 'PCS,PT'),
(10, 2013, '0001/TU.04.06/12/SP/2013\r\n', 0, '410000XXXX\r\n', 'YANUM', 'Sewa Menyewa Kendaraan Bermotor - Innova - Avanza - 2012\r\n', '2013-01-18', '2018-01-17', 'RENT|STATION|INNOVA-AVANZA-2012\r\n', '13.410000XXXX.001\r\n', 'Rent|Toyota-Innova-2.0-G-MT-2012|InJava\r\n', 'Toyota Innova type 2.0 G/MT\r\n', 1, 'UN', '7250000', ' Unit Price \r\n', 'YAYASAN PETROKIMIA GRESIK\r\n', 'YPG'),
(11, 2013, '0001/TU.04.06/12/SP/2013\r\n', 0, '410000XXXX\r\n', 'YANUM', 'Sewa Menyewa Kendaraan Bermotor - Innova - Avanza - 2012\r\n', '2013-01-18', '2017-01-17', 'RENT|STATION|INNOVA-AVANZA-2012\r\n', '13.410000XXXX.001\r\n', 'Rent|Toyota-Avanza-1.5-G-MT-2012|InJava\r\n', 'Toyota Innova type 1.5 G/MT\r\n', 1, 'UN', '4800000', ' Unit Price \r\n', 'YAYASAN PETROKIMIA GRESIK\r\n', 'YPG'),
(12, 2013, '1698/TU.04.06/12/SP/2013\r\n', 0, '410000XXXX\r\n', 'YANUM', 'Sewa Menyewa Kendaraan Bermotor - Mega Carry - 2013\r\n', '2014-02-14', '2017-02-18', 'RENT|PICKUP|MEGACARRY-EXTRAWIDE-2013\r\n', '13.410000XXXX.001\r\n', 'Rent|Suzuki-MegaCarry-ExtraW-2013|InJava\r\n', 'Sewa Kendaraan Bermotor-Mega Carry\r\n', 1, 'UN', '3850000', ' Unit Price \r\n', 'YAYASAN PETROKIMIA GRESIK\r\n', 'YPG'),
(13, 2014, '0112/TU.04.06/09/SP/2014\r\n', 0, '410000XXXX\r\n', 'HAR1', 'Pengecatan Piping & Peralatan Pabrik - Area Amoniak\r\n', '2014-04-01', '2017-03-31', 'PAINT|PIPE&EQP|AMMONIA1\r\n', '14.410000XXXX.001\r\n', 'Paint|Prim-ChloRub-ChloRub|0~6m2\r\n', 'Primer Coat, Chlorinated Rubber 0-6 M\r\n', 1, 'M2', '67000', ' Unit Price \r\n', 'REKSA ENGINEERING, PT\r\n', 'RE,PT'),
(14, 2014, '0112/TU.04.06/09/SP/2014\r\n', 0, '410000XXXX\r\n', 'HAR1', 'Pengecatan Piping & Peralatan Pabrik - Area Amoniak\r\n', '2014-04-01', '2017-03-31', 'PAINT|PIPE&EQP|AMMONIA1\r\n', '14.410000XXXX.002\r\n', 'Paint|Prim-ChloRub-ChloRub|7~12m2\r\n', 'Primer Coat, Chlorinated Rubber 7-12 M\r\n', 1, 'M2', '80000', ' Unit Price \r\n', 'REKSA ENGINEERING, PT\r\n', 'RE,PT'),
(15, 2014, '0112/TU.04.06/09/SP/2014\r\n', 0, '410000XXXX\r\n', 'HAR1', 'Pengecatan Piping & Peralatan Pabrik - Area Amoniak\r\n', '2014-04-01', '2017-03-31', 'PAINT|PIPE&EQP|AMMONIA1\r\n', '14.410000XXXX.003\r\n', 'Paint|Prim-ChloRub-ChloRub|12~20m2\r\n', 'Primer Coat, Chlorinated Rubber 12-20 M\r\n', 1, 'M2', '84000', ' Unit Price \r\n', 'REKSA ENGINEERING, PT\r\n', 'RE,PT');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `role` enum('gudang','admin') NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` int(11) NOT NULL,
  `foto` text NOT NULL,
  `is_active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama`, `username`, `email`, `no_telp`, `role`, `password`, `created_at`, `foto`, `is_active`) VALUES
(1, 'Adminisitrator', 'admin', 'admin@admin.com', '025123456789', 'admin', '$2y$10$qJzoztcJWLao7/cxruqG8.cmWzQlBjY5RfG3ic1c0KB6ex..tsGyu', 1568689561, 'd5f22535b639d55be7d099a7315e1f7f.png', 1),
(17, 'gudang', 'gudang1', 'gudang1@gmail.com', '0877373727', 'gudang', '$2y$10$As3BI1.5UVaA0YV25fMVIO3Fak89d1C9cvFEKTXckwk3A/CkfSxkO', 1591191456, 'user.png', 1),
(18, 'anisah', 'anisah', 'anisahwidya99@gmail.com', '0895639463384', 'admin', '$2y$10$SGPL84nS2IMAw8.KBJ/h7eIpMxmZY4H3NcvBtq9gKQjbceNuKcglG', 1598083892, 'user.png', 1),
(19, 'gudang2', 'gudang2', 'gudang2@gmail.com', '0895639463384', 'gudang', '$2y$10$t4nzMZiAWeUPDk7u4fBWzO2sNKBTHhXIfNO4gzNwXGhQH5aI15PHi', 1598527423, 'user.png', 1),
(20, 'fabrikasi', 'admin6', 'krisnayudha277@gmail.com', '082229643627', 'gudang', '$2y$10$7lEibPKIdXVjLA6D4XA2KOY2hDXoSF5bfLXK3D77CV/ZHo/U3Oy5y', 1598934560, 'user.png', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kategori_service`
--
ALTER TABLE `kategori_service`
  ADD PRIMARY KEY (`id_kategoriservice`),
  ADD KEY `service` (`service`),
  ADD KEY `service_no` (`service_no`);

--
-- Indeks untuk tabel `service_master`
--
ALTER TABLE `service_master`
  ADD PRIMARY KEY (`id_servicemaster`),
  ADD KEY `service` (`service`),
  ADD KEY `service_no` (`service_no`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`) USING BTREE,
  ADD UNIQUE KEY `username` (`username`) USING BTREE;

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `kategori_service`
--
ALTER TABLE `kategori_service`
  MODIFY `id_kategoriservice` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `service_master`
--
ALTER TABLE `service_master`
  MODIFY `id_servicemaster` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `service_master`
--
ALTER TABLE `service_master`
  ADD CONSTRAINT `service_master_ibfk_3` FOREIGN KEY (`service`) REFERENCES `kategori_service` (`service`),
  ADD CONSTRAINT `service_master_ibfk_4` FOREIGN KEY (`service_no`) REFERENCES `kategori_service` (`service_no`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
